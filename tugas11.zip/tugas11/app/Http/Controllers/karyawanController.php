<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\tbl_karyawan;

class karyawanController extends Controller
{

    //Get Data Table
    public function getData(){
        $data = DB::table('tbl_karyawan')->get();
        if(count($data) > 0){
            $res['message'] = "Success!";
            $res['value'] = $data;
            return response($res);
        }else{
            $res['message'] = "Empty!";
            $res['value'] = $data;
            return response($res);
        }
    }

    //Upload Data Table
    public function store(Request $req){
        $this->validate($req, [
            'file' => 'required|max: 2048'
        ]);

        $file = $req->file('file');
        $fileName = time()."_".$file->getClientOriginalName();
        $upploadAddress = 'data_file';
        if($file->move($upploadAddress, $fileName)){
            $data = tbl_karyawan::create([
                'name' => $req->name,
                'jabatan' => $req->jabatan,
                'umur' => $req->umur,
                'alamat' => $req->alamat,
                'foto' => $fileName
            ]);
            $res['message'] = "Success!";
            $res['value'] = $data;
            return response($res);
        }
    }

    //Edit Data Table
    public function update(Request $req){
        if(!empty($req->file)){
            $this->validate($req, [
                'file' => 'required|max: 2048'
            ]);
            
            $file = $req->file('file');
            $fileName = time()."_".$file->getClientOriginalName();
            $upploadAddress = 'data_file';
            $file->move($upploadAddress, $fileName);
            $data = DB::table('tbl_karyawan')->where('id', $req->id)->get();
            foreach($data as $datas){
                @unlink(public_path('data_file'.$datas->foto));
                $x = DB::table('tbl_karyawan')->where('id', $req->id)->update([
                    'name' => $req->name,
                    'jabatan' => $req->jabatan,
                    'umur' => $req->umur,
                    'alamat' => $req->alamat,
                    'foto' => $fileName
                ]);
                $res['message'] = "Success!";
                $res['value'] = $x;
                return response($res);
            }
        }else{
            $data = DB::table('tbl_karyawan')->where('id', $req->id)->get();
            foreach($data as $datas){
                $y = DB::table('tbl_karyawan')->where('id', $req->id)->update([
                    'name' => $req->name,
                    'jabatan' => $req->jabatan,
                    'umur' => $req->umur,
                    'alamat' => $req->alamat,
                ]);
                $req['message'] = "Success!";
                $req['value'] = $y;
                return response($res);
            }
        }
    }

    //Delete Data Table
    public function delete($id){
        $data = DB::table('tbl_karyawan')->where('id', $id)->get();
        foreach($data as $datas){
            if(file_exist(public_path('data_file'.$datas->foto))){
                @unlink(public_path('data_file'.$datas->foto));
                DB::table('tbl_karyawan')->where('id', $id)->delete();
                $res['message'] = "Success!";
                return response($res);
            }else{
                $res['message'] = "Empty!";
                return response($res);
            }
        }
    }
}
